My predicted trajectory from 45 degrees at 10m/s is in predicted_data.txt.
My written report is in report.pdf.

My code is in MATLAB.
Open projectile.m to run my model.
projectile_matlab.m is similar, it uses MATLAB's built-in 'fitlm' function from the machine learning toolbox.
